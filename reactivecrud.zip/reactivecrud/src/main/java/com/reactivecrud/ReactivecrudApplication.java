package com.reactivecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactivecrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactivecrudApplication.class, args);
	}

}
